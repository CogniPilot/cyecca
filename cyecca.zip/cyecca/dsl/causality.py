"""
Causality analysis and BLT decomposition.

This module re-exports from cyecca.ir.causality for backwards compatibility.
The actual implementation is in cyecca.ir.causality.
"""

# Re-export from IR
from cyecca.ir.causality import (
    SortedSystem,
    SolvedEquation,
    ImplicitBlock,
    analyze_causality,
    find_variables,
)

__all__ = [
    "SortedSystem",
    "SolvedEquation",
    "ImplicitBlock",
    "analyze_causality",
    "find_variables",
]
