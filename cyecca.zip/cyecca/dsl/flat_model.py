"""
FlatModel - Backend-agnostic representation of a flattened model.

This module re-exports from cyecca.ir.flat_model for backwards compatibility.
The actual implementation is in cyecca.ir.flat_model.
"""

# Re-export from IR
from cyecca.ir.flat_model import FlatModel

__all__ = ["FlatModel"]
