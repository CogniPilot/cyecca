"""
Simulation utilities for the Cyecca DSL.

This module re-exports from cyecca.ir.simulation for backwards compatibility.
The actual implementation is in cyecca.ir.simulation.
"""

# Re-export everything from ir.simulation for backwards compatibility
from cyecca.ir.simulation import (
    SimulationResult,
    Simulator,
)

__all__ = [
    "SimulationResult",
    "Simulator",
]
