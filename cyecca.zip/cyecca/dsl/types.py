"""
Type definitions for the Cyecca DSL.

This module re-exports from cyecca.ir.types for backwards compatibility.
The actual implementation is in cyecca.ir.types.
"""

# Re-export from IR
from cyecca.ir.types import (
    DType,
    Indices,
    NumericValue,
    Shape,
    SubmodelField,
    Var,
    VarKind,
)

__all__ = [
    "DType",
    "Indices",
    "NumericValue",
    "Shape",
    "SubmodelField",
    "Var",
    "VarKind",
]
