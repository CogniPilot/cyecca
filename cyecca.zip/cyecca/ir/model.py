"""
IRModel - The core intermediate representation for models.

This is the canonical representation that can be created either
via the DSL (@model decorator) or via the direct API.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from beartype import beartype

from cyecca.ir.variable import IRVariable, VariableKind
from cyecca.ir.equation import (
    IREquation,
    IRWhenClause,
    IRInitialEquation,
    IRAssignment,
)


@beartype
@dataclass
class IRModel:
    """
    The Intermediate Representation of a model.

    IRModel is the core data structure that represents a model before
    flattening and compilation. It can be created either:

    1. Via the decorator DSL (convenient, Modelica-like syntax):

        from cyecca.dsl import model, Real, der, equations

        @model
        class Ball:
            h = Real(start=1.0)
            v = Real()

            @equations
            def _(m):
                der(m.h) == m.v
                der(m.v) == -9.81

        ir = Ball().to_ir()

    2. Via the direct API (explicit, no magic):

        from cyecca.ir import IRModel, IRVariable, IREquation

        m = IRModel(name="Ball")
        m.add_variable(IRVariable("h", start=1.0))
        m.add_variable(IRVariable("v"))
        # Add equations...

    Both approaches produce the same IRModel, which can then be
    flattened and compiled to backends.

    Parameters
    ----------
    name : str
        Name of the model
    description : str
        Optional description

    Attributes
    ----------
    variables : dict
        Name -> IRVariable mapping
    equations : list
        List of IREquation
    when_clauses : list
        List of IRWhenClause for event handling
    initial_equations : list
        List of IRInitialEquation (solved at t=0)
    submodels : dict
        Name -> IRModel for hierarchical composition
    """

    name: str
    description: str = ""

    # Core model components
    variables: Dict[str, IRVariable] = field(default_factory=dict)
    equations: List[IREquation] = field(default_factory=list)
    when_clauses: List[IRWhenClause] = field(default_factory=list)
    initial_equations: List[IRInitialEquation] = field(default_factory=list)

    # Hierarchical composition
    submodels: Dict[str, "IRModel"] = field(default_factory=dict)

    # Connectors and connections (for component-based modeling)
    connectors: Dict[str, "IRConnector"] = field(default_factory=dict)
    connections: List[Tuple[str, str]] = field(default_factory=list)

    # Algorithm sections (for procedural code)
    algorithms: List[List[IRAssignment]] = field(default_factory=list)

    # --------------------------------------------------------------------------
    # Variable management
    # --------------------------------------------------------------------------

    def add_variable(self, var: IRVariable) -> IRVariable:
        """
        Add a variable to the model.

        Parameters
        ----------
        var : IRVariable
            Variable to add

        Returns
        -------
        IRVariable
            The added variable (for chaining)

        Raises
        ------
        ValueError
            If a variable with the same name already exists
        """
        if var.name in self.variables:
            raise ValueError(f"Variable '{var.name}' already exists in model '{self.name}'")
        self.variables[var.name] = var
        return var

    def get_variable(self, name: str) -> Optional[IRVariable]:
        """Get a variable by name, or None if not found."""
        return self.variables.get(name)

    def get_variables_by_kind(self, kind: VariableKind) -> List[IRVariable]:
        """Get all variables of a specific kind."""
        return [v for v in self.variables.values() if v.get_kind() == kind]

    @property
    def states(self) -> List[IRVariable]:
        """Get all state variables."""
        return self.get_variables_by_kind(VariableKind.STATE)

    @property
    def algebraic(self) -> List[IRVariable]:
        """Get all algebraic variables."""
        return self.get_variables_by_kind(VariableKind.ALGEBRAIC)

    @property
    def parameters(self) -> List[IRVariable]:
        """Get all parameters."""
        return self.get_variables_by_kind(VariableKind.PARAMETER)

    @property
    def inputs(self) -> List[IRVariable]:
        """Get all input variables."""
        return self.get_variables_by_kind(VariableKind.INPUT)

    @property
    def outputs(self) -> List[IRVariable]:
        """Get all output variables."""
        return self.get_variables_by_kind(VariableKind.OUTPUT)

    @property
    def discrete(self) -> List[IRVariable]:
        """Get all discrete variables."""
        return self.get_variables_by_kind(VariableKind.DISCRETE)

    # --------------------------------------------------------------------------
    # Equation management
    # --------------------------------------------------------------------------

    def add_equation(self, eq: IREquation) -> IREquation:
        """
        Add an equation to the model.

        Parameters
        ----------
        eq : IREquation
            Equation to add

        Returns
        -------
        IREquation
            The added equation (for chaining)
        """
        self.equations.append(eq)
        return eq

    def add_when_clause(self, when: IRWhenClause) -> IRWhenClause:
        """
        Add a when-clause for event handling.

        Parameters
        ----------
        when : IRWhenClause
            When-clause to add

        Returns
        -------
        IRWhenClause
            The added when-clause (for chaining)
        """
        self.when_clauses.append(when)
        return when

    def add_initial_equation(self, eq: IRInitialEquation) -> IRInitialEquation:
        """
        Add an initial equation (solved at t=0).

        Parameters
        ----------
        eq : IRInitialEquation
            Initial equation to add

        Returns
        -------
        IRInitialEquation
            The added equation (for chaining)
        """
        self.initial_equations.append(eq)
        return eq

    # --------------------------------------------------------------------------
    # Submodel management (hierarchical composition)
    # --------------------------------------------------------------------------

    def add_submodel(self, name: str, submodel: "IRModel") -> "IRModel":
        """
        Add a submodel (component) to this model.

        Parameters
        ----------
        name : str
            Instance name for the submodel
        submodel : IRModel
            The submodel to add

        Returns
        -------
        IRModel
            The added submodel (for chaining)
        """
        if name in self.submodels:
            raise ValueError(f"Submodel '{name}' already exists in model '{self.name}'")
        self.submodels[name] = submodel
        return submodel

    def add_connection(self, connector_a: str, connector_b: str) -> None:
        """
        Connect two connectors.

        Parameters
        ----------
        connector_a : str
            Path to first connector (e.g., "motor.flange")
        connector_b : str
            Path to second connector
        """
        self.connections.append((connector_a, connector_b))

    # --------------------------------------------------------------------------
    # Utilities
    # --------------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"IRModel('{self.name}', "
            f"vars={len(self.variables)}, "
            f"eqs={len(self.equations)}, "
            f"when={len(self.when_clauses)}, "
            f"sub={len(self.submodels)})"
        )

    def summary(self) -> str:
        """Return a human-readable summary of the model."""
        lines = [f"Model: {self.name}"]
        if self.description:
            lines.append(f"  {self.description}")
        lines.append(f"  States: {len(self.states)}")
        lines.append(f"  Algebraic: {len(self.algebraic)}")
        lines.append(f"  Parameters: {len(self.parameters)}")
        lines.append(f"  Inputs: {len(self.inputs)}")
        lines.append(f"  Outputs: {len(self.outputs)}")
        lines.append(f"  Discrete: {len(self.discrete)}")
        lines.append(f"  Equations: {len(self.equations)}")
        lines.append(f"  When-clauses: {len(self.when_clauses)}")
        lines.append(f"  Submodels: {len(self.submodels)}")
        return "\n".join(lines)


@beartype
@dataclass
class IRConnector:
    """
    A connector type for component-based modeling.

    Connectors define the interface between components.
    They contain "potential" and "flow" variables that are
    handled specially during connection.

    Parameters
    ----------
    name : str
        Name of the connector type
    potentials : list
        Variables whose values must be equal when connected
    flows : list
        Variables whose sum must be zero when connected
    """

    name: str
    potentials: List[IRVariable] = field(default_factory=list)
    flows: List[IRVariable] = field(default_factory=list)

    def __repr__(self) -> str:
        return f"IRConnector('{self.name}', pot={len(self.potentials)}, flow={len(self.flows)})"
