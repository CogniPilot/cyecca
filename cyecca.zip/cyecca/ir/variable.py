"""
IRVariable - Clean variable representation for the IR.

This module provides a simple, explicit variable type without
the decorator magic of the DSL layer.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Optional, Tuple, Union

import numpy as np
from beartype import beartype


class VariableKind(Enum):
    """Classification of variables in a dynamic system."""

    # Continuous-time variables
    STATE = auto()  # Appears differentiated (has der())
    ALGEBRAIC = auto()  # Continuous, not differentiated

    # Discrete-time variables
    DISCRETE = auto()  # Changes only at events

    # External interface
    INPUT = auto()  # Provided externally
    OUTPUT = auto()  # Computed internally, exposed externally

    # Constants
    PARAMETER = auto()  # Constant during simulation
    CONSTANT = auto()  # Compile-time constant


class DataType(Enum):
    """Data types for variables."""

    REAL = auto()  # Floating point
    INTEGER = auto()  # Integer
    BOOLEAN = auto()  # True/False
    STRING = auto()  # Text (parameters only)


# Type aliases
Shape = Tuple[int, ...]
NumericValue = Union[float, int, bool, str, List[float], List[int], np.ndarray, None]


@beartype
@dataclass(frozen=True)
class IRVariable:
    """
    Immutable variable definition for the IR.

    This is a clean, explicit representation of a variable without
    the magic of the decorator-based DSL.

    Parameters
    ----------
    name : str
        Variable name (must be valid identifier)
    dtype : DataType
        Data type (REAL, INTEGER, BOOLEAN, STRING)
    shape : tuple of int
        Array shape: () for scalar, (n,) for vector, (m,n) for matrix
    start : numeric, optional
        Initial value
    unit : str, optional
        Physical unit (e.g., "m/s", "rad")
    description : str
        Human-readable description
    min : numeric, optional
        Minimum bound
    max : numeric, optional
        Maximum bound
    nominal : numeric, optional
        Nominal value for scaling
    fixed : bool
        If True, start value is used as fixed initial condition
    parameter : bool
        If True, constant during simulation
    discrete : bool
        If True, changes only at events
    input : bool
        If True, externally provided
    output : bool
        If True, computed and exposed
    constant : bool
        If True, compile-time constant
    flow : bool
        If True, uses sum-to-zero connection semantics

    Example
    -------
    >>> theta = IRVariable(
    ...     name="theta",
    ...     dtype=DataType.REAL,
    ...     start=0.5,
    ...     unit="rad",
    ...     description="Pendulum angle",
    ... )
    """

    name: str
    dtype: DataType = DataType.REAL
    shape: Shape = ()
    start: NumericValue = None
    unit: Optional[str] = None
    description: str = ""
    min: NumericValue = None
    max: NumericValue = None
    nominal: NumericValue = None
    fixed: bool = False
    parameter: bool = False
    discrete: bool = False
    input: bool = False
    output: bool = False
    constant: bool = False
    flow: bool = False

    def __post_init__(self) -> None:
        """Validate variable definition."""
        if not self.name.isidentifier():
            raise ValueError(f"Invalid variable name: {self.name!r}")

    @property
    def is_scalar(self) -> bool:
        """True if this is a scalar variable."""
        return self.shape == ()

    @property
    def size(self) -> int:
        """Total number of scalar elements."""
        if self.shape == ():
            return 1
        result = 1
        for dim in self.shape:
            result *= dim
        return result

    @property
    def ndim(self) -> int:
        """Number of dimensions."""
        return len(self.shape)

    def get_kind(self) -> VariableKind:
        """Determine the variable kind from flags."""
        if self.constant:
            return VariableKind.CONSTANT
        if self.parameter:
            return VariableKind.PARAMETER
        if self.input:
            return VariableKind.INPUT
        if self.output:
            return VariableKind.OUTPUT
        if self.discrete:
            return VariableKind.DISCRETE
        # Default: will be classified as STATE or ALGEBRAIC based on equations
        return VariableKind.ALGEBRAIC

    def with_name(self, name: str) -> "IRVariable":
        """Return a copy with a different name."""
        return IRVariable(
            name=name,
            dtype=self.dtype,
            shape=self.shape,
            start=self.start,
            unit=self.unit,
            description=self.description,
            min=self.min,
            max=self.max,
            nominal=self.nominal,
            fixed=self.fixed,
            parameter=self.parameter,
            discrete=self.discrete,
            input=self.input,
            output=self.output,
            constant=self.constant,
            flow=self.flow,
        )

    def __repr__(self) -> str:
        parts = [f"'{self.name}'"]
        if self.dtype != DataType.REAL:
            parts.append(f"dtype={self.dtype.name}")
        if self.shape != ():
            parts.append(f"shape={self.shape}")
        if self.start is not None:
            parts.append(f"start={self.start}")
        if self.parameter:
            parts.append("parameter=True")
        if self.discrete:
            parts.append("discrete=True")
        if self.input:
            parts.append("input=True")
        if self.output:
            parts.append("output=True")
        if self.unit:
            parts.append(f"unit={self.unit!r}")
        return f"IRVariable({', '.join(parts)})"
